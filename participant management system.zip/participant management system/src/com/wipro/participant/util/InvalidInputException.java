package com.wipro.participant.util;

public class InvalidInputException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String toString()
	{
		//Write your code here
		return "Invalid Data in Input";
	}
	

}
