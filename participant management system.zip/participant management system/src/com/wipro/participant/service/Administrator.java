package com.wipro.participant.service;

import com.wipro.participant.bean.ParticipantBean;
import com.wipro.participant.dao.ParticipantDAO;
import com.wipro.participant.util.InvalidInputException;

public class Administrator {
	
	public String addParticipant(ParticipantBean bean)
	{

		try
		{
			if(bean!=null && bean.getName()!="" && bean.getName().length()>=2 &&
					(bean.getSportsQuotaPresent()=="Yes" || bean.getSportsQuotaPresent()=="No"))
			{
				if(bean.getTheoryMark1()<0 || bean.getTheoryMark1()>40 ||
						bean.getTheoryMark2()<0 || bean.getTheoryMark2()>40)
					return "THEORY MARK IS INVALID";
				if(bean.getPracticalMark1()<0 || bean.getPracticalMark1()>60 ||
						bean.getPracticalMark2()<0 || bean.getPracticalMark2()>60)
					return "PRACTICAL MARK IS INVALID";
				ParticipantDAO pd=new ParticipantDAO();
				bean.setId(pd.generateId(bean.getName()));
				int total=((bean.getTheoryMark1()+bean.getTheoryMark2())/2 + (bean.getPracticalMark1()+bean.getPracticalMark2())/2);
				bean.setTotal(total);
				if(bean.getSportsQuotaPresent()=="yes")
				{
					if(total>=70)	bean.setResult("PASS");
					else bean.setResult("FAIL");
				}
				else
				{
					if(total>=75)	bean.setResult("PASS");
					else	bean.setResult("FAIL");
				}
				if(pd.createParticipant(bean)=="SUCCESS")
					return bean.getId()+":"+bean.getResult();
				else
					return "Error";
			}
			else 
			{
				throw new InvalidInputException();
				
			}
		}
		catch(InvalidInputException e)
		{
			e.toString();
			//return "Invalid Data in Input";
		}
		return "Invalid Data in Input";
	}
	
	public static void main(String[] args) {
		
		//Write your code here
		

	}

}
