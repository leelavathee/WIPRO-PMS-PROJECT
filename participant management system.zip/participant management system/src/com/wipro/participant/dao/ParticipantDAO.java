package com.wipro.participant.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.wipro.participant.bean.ParticipantBean;
import com.wipro.participant.util.DBUtil;

public class ParticipantDAO {
	
	
	public String generateId(String studentname)
	{
		String id="";
		Connection conn = DBUtil.getDBConnection();
		PreparedStatement ps=null;
		ResultSet rs=null;
		try 
		{
			ps=conn.prepareStatement("select PARTICIPANTID_SEQ.nextval from dual");
			rs=ps.executeQuery();

			id = studentname.substring(studentname.length()-2);
			id = id.toUpperCase();
			if(rs.next())
			{
				id=id+rs.getInt(1);
			}
		
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return id;
	}

	public String createParticipant(ParticipantBean bean)
	{
		String result="";
		Connection con = DBUtil.getDBConnection();
		PreparedStatement ps=null;
		try 
		{
			ps = con.prepareStatement("insert into PARTICIPANT_TABLE values(?,?,?,?,?,?,?,?,?)");
			ps.setString(1, bean.getId());
			ps.setString(2, bean.getName());
			ps.setInt(3, bean.getTheoryMark1());
			ps.setInt(4, bean.getTheoryMark2());
			ps.setInt(5, bean.getPracticalMark1());
			ps.setInt(6, bean.getPracticalMark2());
			ps.setString(7, bean.getSportsQuotaPresent());
			ps.setInt(8, bean.getTotal());
			ps.setString(9, bean.getResult());
			int n=ps.executeUpdate();
			if(n>0)
				result="SUCCESS";
			else
				return "FAIL";
		} 
		catch (SQLException e) 
		{
			return "FAIL";
		}
		return result;
	}
	
	
}
